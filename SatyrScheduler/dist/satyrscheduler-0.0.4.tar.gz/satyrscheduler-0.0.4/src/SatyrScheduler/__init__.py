

from SatyrScheduler.GetData.GetData import GetData

from SatyrScheduler.Schedule.Schedule import InitSchedule